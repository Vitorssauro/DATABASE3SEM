<?php
include 'functions.php';
?>

<?=template_header('Consultar Clientes')?>


<?=template_footer()?>